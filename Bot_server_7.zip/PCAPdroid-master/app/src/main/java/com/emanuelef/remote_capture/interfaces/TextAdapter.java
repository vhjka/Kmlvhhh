package com.emanuelef.remote_capture.interfaces;

public interface TextAdapter {
    String getItemText(int pos);
    int getCount();
}
