The subfolders in this directory contain pre-generated autotools files. Using these files removes the need to install autotools and allows to build PCAPdroid in Windows.
To update the files, run `./refresh.sh` in this folder.
